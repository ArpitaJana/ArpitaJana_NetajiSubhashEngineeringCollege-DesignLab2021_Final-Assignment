CREATE DATABASE IF NOT EXISTS loginsystem;
USE loginsystem;
CREATE TABLE log ( 
	id int AUTO_INCREMENT,
	username varchar(20),
	fullname varchar(20),
	phone varchar(10);
	password varchar(128),
	PRIMARY KEY (id)
);
